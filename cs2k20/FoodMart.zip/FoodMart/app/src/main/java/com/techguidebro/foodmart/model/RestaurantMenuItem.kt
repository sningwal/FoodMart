package com.techguidebro.foodmart.model

data class RestaurantMenuItem(val ItemId: String, val ItemName: String, val Price: String)