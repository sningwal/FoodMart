package com.techguidebro.foodmart.model

data class Restaurant(
    var Id: String,
    var restaurantName: String,
    var restaurantRating: String,
    var cost_for_one: String,
    var restaurantImage: String
)